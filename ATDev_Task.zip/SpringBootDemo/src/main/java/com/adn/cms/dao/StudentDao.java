package com.adn.cms.dao;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.adn.cms.entity.Student;

@Repository
public class StudentDao {

	@Autowired
	private SessionFactory sessionFactory;

	public List<Student> getStudentDetails() {
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> studentList = criteria.list();
		return studentList;
	}

	public String insertStudentDetails(Student student) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		session.save(student);
		tr.commit();
		return "Student Details Inserted Successfully..!!";
	}

	public String updateStudentDetails(Student student) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		session.update(student);
		tr.commit();
		return "Student Details Updated Successfully..!!";
	}

	public String deleteStudentDetails(Student student) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Student stud = session.load(Student.class, student.getSrNo());
		session.delete(stud);
		tr.commit();
		return "Student Details Deleted Successfully..!!";
	}

	
	
}
