package com.adn.cms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {

	private int id;
	private long name;
	

	@id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getName() {
		return name;
	}

	public void setName(long name) {
		this.name = name;
	}

	
}
