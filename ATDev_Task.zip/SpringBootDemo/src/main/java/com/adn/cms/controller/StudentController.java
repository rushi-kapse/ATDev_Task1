package com.adn.cms.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.adn.cms.entity.Student;
import com.adn.cms.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentservice;

	@GetMapping("studentdetails")
	public List<Student> getStudentDetails() {
		return studentservice.getStudentDetails();
	}

	@PostMapping("insertstudentdetails")
	public String insertStudentDetails(@RequestBody Student student) {
		return studentservice.insertStudentDetails(student);
	}

	@PutMapping("updatestudentdetails")
	public String updateStudentDetails(@RequestBody Student student) {
		return studentservice.updateStudentDetails(student);
	}

	@DeleteMapping("deletestudentdetails")
	public String deleteStudentDetails(@RequestBody Student student) {
		return studentservice.deleteStudentDetails(student);
	}

	
}
