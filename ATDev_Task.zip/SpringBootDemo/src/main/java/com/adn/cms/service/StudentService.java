package com.adn.cms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.adn.cms.dao.StudentDao;
import com.adn.cms.entity.Student;

@Service
public class StudentService {

	@Autowired
	private StudentDao studentdao;

	public List<Student> getStudentDetails() {
		return studentdao.getStudentDetails();
	}

	public String insertStudentDetails(Student student) {
		return studentdao.insertStudentDetails(student);
	}

	public String updateStudentDetails(Student student) {
		return studentdao.updateStudentDetails(student);
	}

	public String deleteStudentDetails(Student student) {
		return studentdao.deleteStudentDetails(student);
	}

	
}
